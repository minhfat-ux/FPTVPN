#!/bin/bash
# FPT Harness — Mac-side tunnel installer (self-healing, no autossh needed).
# Usage: bash setup-tunnel.sh <VPS_IP> [SSH_USER=root] [SSH_PORT=22]
set -euo pipefail

VPS="${1:?Usage: bash setup-tunnel.sh <VPS_IP> [SSH_USER=root] [SSH_PORT=22]}"
SSH_USER="${2:-root}"
SSH_PORT="${3:-22}"
KEY="$HOME/.ssh/fpt_tunnel"
WRAPPER="$HOME/dsh-tunnel.sh"

echo "==> [1/4] SSH key riêng cho tunnel"
if [ ! -f "$KEY" ]; then
  ssh-keygen -t ed25519 -f "$KEY" -N '' -C 'fpt-tunnel' -q
  echo "    Key tạo xong: $KEY.pub"
else
  echo "    Key đã có: $KEY"
fi

echo "==> [2/4] Cài pubkey lên VPS $SSH_USER@$VPS (nhập password SSH khi được hỏi)"
PUB=$(cat "$KEY.pub")
ssh -p "$SSH_PORT" "$SSH_USER@$VPS" "mkdir -p ~/.ssh && chmod 700 ~/.ssh && grep -qF '$PUB' ~/.ssh/authorized_keys 2>/dev/null || echo '$PUB' >> ~/.ssh/authorized_keys; chmod 600 ~/.ssh/authorized_keys"

echo "==> [3/4] Wrapper self-healing: $WRAPPER"
cat > "$WRAPPER" <<WRAPEOF
#!/bin/bash
# FPT Harness tunnel — waits for network, clears stale port, connects, retries.
VPS=$VPS
KEY=$KEY
for i in \$(seq 1 15); do ping -c 1 -W 2 "\$VPS" >/dev/null 2>&1 && break; sleep 3; done
for attempt in \$(seq 1 5); do
  ssh -i "\$KEY" -o IdentitiesOnly=yes -o ConnectTimeout=8 -o StrictHostKeyChecking=accept-new root@\$VPS 'fuser -k 3080/tcp 2>/dev/null; true' 2>/dev/null
  ssh -i "\$KEY" -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new -o ServerAliveInterval=20 -o ServerAliveCountMax=3 -o ExitOnForwardFailure=yes -o ConnectTimeout=15 -C -N -R 127.0.0.1:3080:127.0.0.1:3080 root@\$VPS && exit 0
  sleep 3
done
exit 1
WRAPEOF
chmod +x "$WRAPPER"
echo "    Wrapper đã tạo (chờ mạng sau wake + dọn port kẹt + retry 5 lần)"

echo "==> [4/4] LaunchAgent com.fpt.tunnel"
PLIST="$HOME/Library/LaunchAgents/com.fpt.tunnel.plist"
mkdir -p "$HOME/Library/LaunchAgents"
cat > "$PLIST" <<PLISTEOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>Label</key>
	<string>com.fpt.tunnel</string>
	<key>ProgramArguments</key>
	<array>
		<string>/bin/bash</string>
		<string>${WRAPPER}</string>
	</array>
	<key>ThrottleInterval</key>
	<integer>5</integer>
	<key>RunAtLoad</key>
	<true/>
	<key>KeepAlive</key>
	<true/>
	<key>StandardOutPath</key>
	<string>/tmp/fpt-tunnel.out.log</string>
	<key>StandardErrorPath</key>
	<string>/tmp/fpt-tunnel.err.log</string>
</dict>
</plist>
PLISTEOF
launchctl bootout "gui/$(id -u)" "$PLIST" 2>/dev/null || true
launchctl bootstrap "gui/$(id -u)" "$PLIST"
echo "    Daemon đã nạp (tự phục hồi, chạy lại khi reboot)."

echo
echo "==> Xong! Kiểm tra: ssh -p $SSH_PORT $SSH_USER@$VPS 'ss -tlnp | grep 3080'"
