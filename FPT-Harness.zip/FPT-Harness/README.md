# FPT Harness 🚀

Gói đóng gói toàn bộ DeepSeek Harness đã được tùy biến thành **FPT Harness**:
đổi tên, theme màu FlowVPN, logo FPT, browse-picker hoạt động từ xa, và bộ
triển khai VPS (Caddy + nginx auth gate + login form) — tái sử dụng trên máy khác.

## Cấu trúc

```
FPT-Harness/
├── patches/
│   ├── apply-fpt-patches.py   # áp toàn bộ vá vào DSH install (idempotent, có backup)
│   └── favicon.svg            # logo FPT
├── profile/
│   └── cordis.patch.yml       # pin browse directory picker (workspace từ xa)
├── vps/
│   ├── Caddyfile              # Caddy + HTTPS Let's Encrypt + domain
│   ├── nginx-dhs-gate         # nginx auth_request gate (cookie login)
│   ├── dhs-auth-server.py     # auth server (form login, bcrypt, session 30 ngày)
│   ├── dhs-auth.service       # systemd unit
│   └── install-vps.sh         # cài tự động lên VPS mới (Ubuntu/Debian)
├── mac/
│   ├── com.dsh.tunnel.plist   # mẫu launchd (tham số hóa bởi setup script)
│   └── setup-tunnel.sh        # tạo key + autossh + launchd reverse tunnel
└── README.md
```

## Kiến trúc khi triển khai

```
Trình duyệt (mọi thiết bị) → https://dhs.<domain>
  → VPS: Caddy (HTTPS Let's Encrypt)
  → nginx 127.0.0.1:3081 (auth_request: cookie session → chưa đăng nhập thì redirect /login)
  → dhs-auth :9090 (form login, bcrypt, cookie 30 ngày)
  → SSH reverse tunnel 127.0.0.1:3080 (autossh + launchd, Host→localhost)
  → DSH GUI trên Mac
```

## Cách 1 — Deploy trên Mac mới (máy chạy DSH)

1. **Cài DSH** (như máy hiện tại — global npm install @deepseek-ai/dsh, `npm i -g @deepseek-ai/dsh`).
2. **Áp bản vá FPT**:
   ```bash
   cd FPT-Harness/patches
   python3 apply-fpt-patches.py
   ```
   (Script tự tìm DSH install; mọi file gốc được backup `.fpt.bak`. Chạy lại vô hại — bỏ qua những gì đã vá.)
3. **Khởi động lại DSH** (Ctrl+C rồi `dsh web`), refresh browser.
4. **Kết nối VPS** (để dùng từ xa):
   ```bash
   bash FPT-Harness/mac/setup-tunnel.sh <VPS_IP> root 22
   ```

## Cách 2 — Deploy trên VPS mới

1. Trỏ DNS: `dhs.<domain>` → IP VPS (A record).
2. Copy thư mục `vps/` lên VPS, chạy:
   ```bash
   sudo bash install-vps.sh dhs.<domain>
   ```
   (Đổi user/password login nếu muốn: `AUTH_USER=admin AUTH_PASS='...' sudo bash install-vps.sh dhs.<domain>`)
3. Sau đó chạy tunnel từ Mac (Cách 1 bước 4).

## Thông tin mặc định

- **Login form**: user `dhs` / password `fgMR6h53TC5kMmRW` (đổi bằng `AUTH_USER`/`AUTH_PASS` khi cài VPS).
- **Ngưỡng housekeeping** (nếu cài thêm agent dọn ổ — xem thêm tài liệu riêng): 30GB/15GB.

## Khi update DSH

Các bản vá nằm trong `node_modules` — sau khi `npm update`, chạy lại
`python3 apply-fpt-patches.py` để áp lại (script kiểm tra & bỏ qua phần đã vá).

## Lưu ý bảo mật

- Đổi password root VPS + password login DHS sau khi triển khai.
- Chỉ mở port 22/80/443 trên firewall VPS.
- Cookie session HttpOnly + SameSite=Lax; nginx gate ép auth trên mọi request kể cả WebSocket.
