#!/usr/bin/env python3
"""dhs-auth: cookie-based login for the DSH GUI reverse proxy."""
import http.cookies
import json
import os
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

import bcrypt

USER = "dhs"
PASS_HASH = "$2b$14$PO09YgPjEQqztPOeo4CJVuQr1ZuCBpkNSj5eawCj2XxpwXe..BIpy"
SESSION_FILE = "/var/lib/dhs-auth/sessions.json"
SESSION_TTL = 30 * 24 * 3600  # 30 days

sessions = {}
lock = threading.Lock()

def load_sessions():
    global sessions
    try:
        with open(SESSION_FILE) as f:
            sessions = json.load(f)
    except Exception:
        sessions = {}

def save_sessions():
    try:
        os.makedirs(os.path.dirname(SESSION_FILE), exist_ok=True)
        tmp = SESSION_FILE + ".tmp"
        with open(tmp, "w") as f:
            json.dump(sessions, f)
        os.replace(tmp, SESSION_FILE)
    except Exception as e:
        print("save error:", e)

load_sessions()

LOGIN_PAGE = """<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>FPT China Harness &mdash; D&#259;ng nh&#7853;p</title>
<style>
:root{color-scheme:dark}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;background:#0d1117;color:#e6edf3;display:flex;align-items:center;justify-content:center;min-height:100vh}
.card{background:#161b22;border:1px solid #30363d;border-radius:12px;padding:40px 36px;width:340px;box-shadow:0 8px 24px rgba(0,0,0,.4)}
h1{font-size:20px;margin-bottom:6px}
.sub{color:#8b949e;font-size:13px;margin-bottom:24px}
label{display:block;font-size:13px;color:#8b949e;margin:14px 0 6px}
input{width:100%;padding:10px 12px;border-radius:8px;border:1px solid #30363d;background:#0d1117;color:#e6edf3;font-size:14px}
input:focus{outline:none;border-color:#2f81f7}
button{width:100%;margin-top:22px;padding:11px;border:0;border-radius:8px;background:#2f81f7;color:#fff;font-size:15px;font-weight:600;cursor:pointer}
button:hover{background:#388bfd}
.err{color:#f85149;font-size:13px;margin-top:14px}
</style>
</head>
<body>
<div class="card">
<img src="/favicon.png" alt="FPT China Harness" style="width:56px;height:56px;object-fit:contain;margin:0 auto 12px;display:block"><h1>FPT China Harness</h1>
<div class="sub">&#272;&#259;ng nh&#7853;p &#273;&#7875; truy c&#7853;p</div>
<form method="post" action="/login">
<label for="username">T&#234;n &#273;&#259;ng nh&#7853;p</label>
<input id="username" name="username" autocomplete="username" autofocus required>
<label for="password">M&#7853;t kh&#7849;u</label>
<input id="password" name="password" type="password" autocomplete="current-password" required>
<button type="submit">&#272;&#259;ng nh&#7853;p</button>
</form>
<!--ERR-->
</div>
</body>
</html>"""

class Handler(BaseHTTPRequestHandler):
    server_version = "dhs-auth"

    def log_message(self, fmt, *args):
        pass

    def _cookie(self):
        raw = self.headers.get("Cookie", "")
        try:
            c = http.cookies.SimpleCookie(raw)
            m = c.get("dhs_auth")
            return m.value if m else None
        except Exception:
            return None

    def _authed(self):
        tok = self._cookie()
        if not tok:
            return False
        with lock:
            exp = sessions.get(tok)
            if exp is None:
                return False
            if time.time() > exp:
                del sessions[tok]
                save_sessions()
                return False
        return True

    def _send(self, code, body=b"", ctype="text/html; charset=utf-8", headers=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (headers or []):
            self.send_header(k, v)
        self.end_headers()
        if body:
            self.wfile.write(body)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/login":
            self._send(200, LOGIN_PAGE.encode())
        elif path == "/logout":
            tok = self._cookie()
            if tok:
                with lock:
                    sessions.pop(tok, None)
                    save_sessions()
            self._send(302, b"", headers=[("Location", "/login"),
                                          ("Set-Cookie", "dhs_auth=; Path=/; HttpOnly; SameSite=Lax; Secure; Max-Age=0")])
        elif path == "/check":
            if self._authed():
                self._send(200, b"ok")
            else:
                self._send(401, b"unauthorized")
        else:
            self._send(404, b"not found")

    def do_POST(self):
        path = urlparse(self.path).path
        if path != "/login":
            self._send(404, b"not found")
            return
        length = int(self.headers.get("Content-Length", 0) or 0)
        body = self.rfile.read(length).decode("utf-8", "replace")
        params = parse_qs(body)
        user = (params.get("username") or [""])[0]
        pwd = (params.get("password") or [""])[0]
        ok = False
        if user == USER and pwd:
            try:
                ok = bcrypt.checkpw(pwd.encode(), PASS_HASH.encode())
            except Exception:
                ok = False
        if ok:
            tok = secrets.token_urlsafe(32)
            with lock:
                sessions[tok] = time.time() + SESSION_TTL
                save_sessions()
            self._send(302, b"", headers=[
                ("Location", "/"),
                ("Set-Cookie", "dhs_auth=%s; Path=/; HttpOnly; SameSite=Lax; Secure; Max-Age=%d" % (tok, SESSION_TTL)),
            ])
        else:
            time.sleep(1)  # brute-force slowdown
            self._send(200, LOGIN_PAGE.replace("<!--ERR-->",
                       '<p class="err">Sai t&#234;n &#273;&#259;ng nh&#7853;p ho&#7863;c m&#7853;t kh&#7849;u</p>').encode())

if __name__ == "__main__":
    srv = ThreadingHTTPServer(("127.0.0.1", 9090), Handler)
    print("dhs-auth listening on 127.0.0.1:9090")
    srv.serve_forever()
