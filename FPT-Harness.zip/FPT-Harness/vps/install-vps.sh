#!/bin/bash
# FPT Harness — VPS installer (Ubuntu/Debian).
# Run as root:  sudo bash install-vps.sh <dhs-domain>
#   <dhs-domain>  e.g. dhs.example.com  (DNS A record must point to this VPS)
set -euo pipefail

DOMAIN="${1:?Usage: sudo bash install-vps.sh <dhs-domain>}"
SRC="$(cd "$(dirname "$0")" && pwd)"
AUTH_USER="${AUTH_USER:-dhs}"
AUTH_PASS="${AUTH_PASS:-fgMR6h53TC5kMmRW}"

echo "==> [1/7] System packages"
export DEBIAN_FRONTEND=noninteractive
apt-get update -q
apt-get install -y -q nginx python3 python3-bcrypt curl apt-transport-https ca-certificates >/dev/null
if ! command -v caddy >/dev/null 2>&1; then
  VER=$(curl -s https://api.github.com/repos/caddyserver/caddy/releases/latest | grep -m1 tag_name | cut -d\" -f4)
  curl -sL -o /tmp/caddy.deb "https://github.com/caddyserver/caddy/releases/download/${VER}/caddy_${VER#v}_linux_amd64.deb"
  dpkg -i /tmp/caddy.deb >/dev/null 2>&1 || apt-get install -y -q -f >/dev/null
fi

echo "==> [2/7] dhs-auth server (cookie login) on 127.0.0.1:9090"
mkdir -p /opt/dhs-auth /var/lib/dhs-auth
cp "$SRC/dhs-auth-server.py" /opt/dhs-auth/server.py
AUTH_HASH=$(python3 -c "import bcrypt;print(bcrypt.hashpw(b'$AUTH_PASS',bcrypt.gensalt(14)).decode())")
python3 - "$AUTH_USER" "$AUTH_HASH" <<'PYEOF'
import sys, re
src = "/opt/dhs-auth/server.py"
s = open(src).read()
s = re.sub(r'^USER = .*$', 'USER = %r' % sys.argv[1], s, flags=re.M)
s = re.sub(r'^PASS_HASH = .*$', 'PASS_HASH = %r' % sys.argv[2], s, flags=re.M)
open(src, 'w').write(s)
print("    baked auth user/hash into server.py")
PYEOF
cp "$SRC/dhs-auth.service" /etc/systemd/system/dhs-auth.service
systemctl daemon-reload && systemctl enable --now dhs-auth >/dev/null 2>&1
sleep 1
systemctl is-active dhs-auth >/dev/null && echo "    dhs-auth active" || echo "    WARN: dhs-auth not active — check /opt/dhs-auth/server.py"

echo "==> [3/7] nginx auth gate on 127.0.0.1:3081"
cp "$SRC/nginx-dhs-gate" /etc/nginx/sites-available/dhs-gate
ln -sf /etc/nginx/sites-available/dhs-gate /etc/nginx/sites-enabled/dhs-gate
rm -f /etc/nginx/sites-enabled/default
nginx -t >/dev/null && systemctl enable --now nginx >/dev/null 2>&1 && echo "    nginx active"

echo "==> [4/7] Caddy with $DOMAIN (automatic HTTPS)"
sed "s/dhs\.meetflowai\.site/$DOMAIN/g" "$SRC/Caddyfile" > /etc/caddy/Caddyfile
mkdir -p /var/www/flowvpn
systemctl restart caddy && sleep 2 && echo "    caddy active"

echo "==> [5/7] Firewall: open 22/80/443"
if command -v ufw >/dev/null 2>&1; then
  ufw allow 22/tcp >/dev/null 2>&1 || true
  ufw allow 80/tcp >/dev/null 2>&1 || true
  ufw allow 443/tcp >/dev/null 2>&1 || true
  echo "    ufw rules set (enable with: ufw enable)"
fi

echo "==> [6/7] Verify HTTPS + login"
sleep 3
echo "    https://$DOMAIN -> HTTP $(curl -s -o /dev/null -w '%{http_code}' -m 15 https://$DOMAIN/ || echo '?')"
echo "    login: user $AUTH_USER / password $AUTH_PASS"

echo "==> [7/7] NEXT STEP — tunnel từ Mac chạy DSH:"
echo "    bash mac/setup-tunnel.sh <VPS_IP> <SSH_USER=root>"
echo
echo "Done. Nếu chưa có DNS: thêm A record $DOMAIN -> IP VPS này."
